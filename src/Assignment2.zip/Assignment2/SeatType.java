package Assignment2;

/**
 * this enum contains the seat types
 * @author Liam Yates - 18016696
 */

public enum SeatType {

	WINDOW, AISLE, MIDDLE;
	
}
